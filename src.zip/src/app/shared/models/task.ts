export interface Task {
    id?: number;
    taskName: string;
    description: string;
    duration: number;
    totalDuration?: number;
    functionalityId: number;
  }
  
