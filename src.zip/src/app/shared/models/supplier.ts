export interface Supplier {
    id?: number
    society?: string,
    firstName?: string,
    lastName?: string,
    email?: string,
    phone?: string
}
