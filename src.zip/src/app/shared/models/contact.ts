export interface Contact{
    id?:number,
    firstName?: string;
    lastName?: string;
    email?: string;
    address?: string;
    phone?: string;
    projectId?: number;
}
