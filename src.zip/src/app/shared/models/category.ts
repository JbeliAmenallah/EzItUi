export interface Category {
    id?: number;
    categoryName?: string;
    duration?: number;
    startDate?: Date;
    endDate?: Date;
    projectId?: number;
  }
  