import { Component } from '@angular/core';

@Component({
  selector: 'app-functionality-details',
  templateUrl: './functionality-details.component.html',
  styleUrl: './functionality-details.component.css'
})
export class FunctionalityDetailsComponent {

}
